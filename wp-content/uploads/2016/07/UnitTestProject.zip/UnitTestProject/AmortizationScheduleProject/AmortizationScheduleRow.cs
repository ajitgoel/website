﻿using System;

namespace AmortizationScheduleProject
{ 
    public class AmortizationScheduleRow
    {
        public double GetMonthlyPaymentAmount()
        {
            return Math.Round(MonthlyPaymentAmount, 2, MidpointRounding.AwayFromZero);
        }
        public double MonthlyPaymentAmount { private get; set; }
        public double GetInterestAmount()
        {
            return Math.Round(InterestAmount, 2, MidpointRounding.AwayFromZero);
        }
        public double InterestAmount { private get; set; }
        public double GetTotalInterestAmount()
        {
            return Math.Round(TotalInterestAmount, 2, MidpointRounding.AwayFromZero);
        }
        public double TotalInterestAmount { private get; set; }
        public double GetPrincipalAmount()
        {
            var principalAmount = MonthlyPaymentAmount - InterestAmount;
            return Math.Round(principalAmount, 2, MidpointRounding.AwayFromZero);
        }
        public string GetDate()
        {
            return Date.ToString("MMM yyyy");
        }
        public DateTime Date { private get; set; }
    }
}
