﻿using System;
using System.Collections.Generic;

namespace AmortizationScheduleProject
{
    public class AmortizationSchedule: IAmortizationSchedule
    {
        public List<AmortizationScheduleRow> Get(double annualPercentageRate,
             double loanAmount, int loanPeriodInYears, DateTime loanStartDate)
        {
            if (annualPercentageRate <= 0 || loanAmount <= 0 || loanPeriodInYears <= 0 ||
                loanStartDate <= DateTime.MinValue)
            {
                throw new ArgumentException("Invalid arguments");
            }

            #region Calculate monthly payment rounded to 2 digits
            const int NoOfMonthsInYear = 12;
            var loanPeriodInMonths = loanPeriodInYears * NoOfMonthsInYear;
            var effectiveInterestRate = annualPercentageRate / (NoOfMonthsInYear * 100);
            var toThePowerOfVariable = Math.Pow(1 + effectiveInterestRate, -loanPeriodInMonths);
            var monthlyPayment = (loanAmount * (effectiveInterestRate / (1 - toThePowerOfVariable)));
            #endregion

            #region Calculate payment schedule based on monthly payment and loan start date
            var amortizationSchedule = new List<AmortizationScheduleRow>();
            var currentMonthCounter = loanStartDate.AddMonths(1);
            var currentBalance = loanAmount;
            double totalInterestAmount = 0;
            for (var counter = 0; counter < loanPeriodInMonths; counter++)
            {
                var interestAmount = effectiveInterestRate * currentBalance;
                totalInterestAmount = totalInterestAmount + interestAmount;
                var amortizationScheduleRow = new AmortizationScheduleRow
                {
                    Date = currentMonthCounter,
                    MonthlyPaymentAmount = monthlyPayment,
                    InterestAmount = interestAmount,
                    TotalInterestAmount = totalInterestAmount
                };
                amortizationSchedule.Add(amortizationScheduleRow);

                currentBalance = currentBalance - amortizationScheduleRow.GetPrincipalAmount();
                currentMonthCounter = currentMonthCounter.AddMonths(1);
            }
            #endregion
            return amortizationSchedule;
        }
    }
}
