﻿using System;
using System.Collections.Generic;

namespace AmortizationScheduleProject
{
    public interface IAmortizationSchedule
    {
        List<AmortizationScheduleRow> Get(double annualPercentageRate, double loanAmount, int loanPeriodInYears, DateTime loanStartDate);
    }
}
