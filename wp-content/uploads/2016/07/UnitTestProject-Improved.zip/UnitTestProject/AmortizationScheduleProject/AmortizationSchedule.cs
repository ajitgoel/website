﻿using System;
using System.Collections.Generic;

namespace AmortizationScheduleProject
{
    public class AmortizationSchedule: IAmortizationSchedule
    {
        public IList<AmortizationScheduleRow> Get(double annualPercentageRate, 
            double loanAmount, int loanPeriodInYears, DateTime loanStartDate)
        {
            if (annualPercentageRate <= 0 || loanAmount <= 0 || loanPeriodInYears <= 0 ||
                loanStartDate <= DateTime.MinValue || loanStartDate == DateTime.MaxValue)
            {
                throw new ArgumentException("Invalid arguments");
            }
            //If the code below does not throw an exception then 
            //the "loanStartDate" has been validated against the "loanPeriodInYears"
            DateTime addYears = loanStartDate.AddYears(loanPeriodInYears);
            
            #region Calculate monthly payment rounded to 2 digits
            const int NoOfMonthsInYear = 12;
            var loanPeriodInMonths = loanPeriodInYears * NoOfMonthsInYear;
            var effectiveInterestRateInDouble = annualPercentageRate / (NoOfMonthsInYear * 100);
            var toThePowerOfVariable = Math.Pow(1 + effectiveInterestRateInDouble, -loanPeriodInMonths);
            var monthlyPayment = (decimal) (loanAmount * (effectiveInterestRateInDouble / (1 - toThePowerOfVariable)));
            #endregion

            #region Calculate payment schedule based on monthly payment and loan start date
            //Initialize the collection(for performance) based on the 
            //no of elements that it is supposed to hold
            var amortizationSchedule =
            new List<AmortizationScheduleRow>(loanPeriodInMonths);
            var currentMonthCounter = loanStartDate.AddMonths(1);
            var currentBalance = (decimal) loanAmount;
            decimal totalInterestAmount = 0;
            for (var counter = 0; counter < loanPeriodInMonths; counter++)
            {
                var interestAmount = (decimal) (effectiveInterestRateInDouble * (double) currentBalance);
                totalInterestAmount = (totalInterestAmount + interestAmount);
                var amortizationScheduleRow = new AmortizationScheduleRow
                {
                    Date = currentMonthCounter,
                    MonthlyPaymentAmount = monthlyPayment,
                    InterestAmount = interestAmount,
                    TotalInterestAmount = totalInterestAmount
                };
                amortizationSchedule.Add(amortizationScheduleRow);

                currentBalance = currentBalance - amortizationScheduleRow.GetPrincipalAmount();
                currentMonthCounter = currentMonthCounter.AddMonths(1);
            }
            #endregion
            return amortizationSchedule;
        }
    }
}
