﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AmortizationScheduleProject;

namespace AmortizationScheduleUnitTest
{
    [TestClass]
    public class AmortizationScheduleTester
    {
        const double annualPercentageRate = 3.5;
        const double loanAmount = 300000;
        const int loanPeriodInYears = 15;
        readonly DateTime loanStartDate = new DateTime(2016, 7, 1);
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest()
        {
            const int NoOfMonthsInYear = 12;
            var monthlyPaymentSchedule = new AmortizationSchedule().Get(annualPercentageRate, loanAmount,
                loanPeriodInYears, loanStartDate);
            Assert.IsFalse(monthlyPaymentSchedule == null);
            Assert.IsFalse(monthlyPaymentSchedule.Count <= 1);
            var secondMonthPaymentSchedule = monthlyPaymentSchedule[1];
            Assert.AreEqual(monthlyPaymentSchedule.Count, 15 * NoOfMonthsInYear);
            Assert.AreEqual(secondMonthPaymentSchedule.GetMonthlyPaymentAmount(), (decimal) 2144.65);
            Assert.AreEqual(secondMonthPaymentSchedule.GetDate(), "Sep 2016");
            Assert.AreEqual(secondMonthPaymentSchedule.GetInterestAmount(), (decimal) 871.30);
            Assert.AreEqual(secondMonthPaymentSchedule.GetTotalInterestAmount(), (decimal) 1746.30);
            Assert.AreEqual(secondMonthPaymentSchedule.GetPrincipalAmount(), (decimal) 1273.35);
        }
        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest1()
        {
            new AmortizationSchedule().Get(0, loanAmount,
                loanPeriodInYears, loanStartDate);
        }

        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest2()
        {
            new AmortizationSchedule().Get(annualPercentageRate, 0,
                loanPeriodInYears, loanStartDate);
        }
        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest3()
        {
            new AmortizationSchedule().Get(annualPercentageRate, loanAmount, 0, loanStartDate);
        }
        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest4()
        {
            new AmortizationSchedule().Get(annualPercentageRate, loanAmount,
                loanPeriodInYears, DateTime.MinValue);
        }

        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest5()
        {
            new AmortizationSchedule().Get(annualPercentageRate, loanAmount,
                loanPeriodInYears, DateTime.MaxValue);
        }

        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        [TestMethod]
        public void GetAmortizationScheduleExceptionTest6()
        {
            new AmortizationSchedule().Get(annualPercentageRate, loanAmount,
                loanPeriodInYears, DateTime.MaxValue.AddYears(-1));
        }
    }
}
